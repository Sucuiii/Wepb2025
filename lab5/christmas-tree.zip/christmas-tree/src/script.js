// 產生完整聖誕樹
function tree(n) {
    printTreeTop(n);
    printTreeBottom(n);
}

// 樹的上半部 (星星數量為 1, 3, 5, 7)
function printTreeTop(n) {
    let stars = 1; // 初始星星數
    for (let i = 0; i < n; i++) {
        console.log(repeatchar((n - i - 1), ' ') + repeatchar(stars, '*'));
        stars += 2; // 每層增加 2 顆星
    }
}

// 樹的下半部 (樹幹，3 行，每行 1 顆星)
function printTreeBottom(n) {
    for (let i = 0; i < 3; i++) {
        console.log(repeatchar(n - 1, ' ') + '*');
    }
}

// 重複產生字元
function repeatchar(n, arg_char = ' ') {
    return String(arg_char).repeat(n);
}

// 呼叫函數
tree(4);





